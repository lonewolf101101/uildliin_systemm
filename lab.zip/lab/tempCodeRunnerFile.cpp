#include <iostream>

int deleteIntegerFromArray(int arr[], int size, int target) {

    //shift elements to remove it
    for (int i = target; i < size - 1; ++i) {
        arr[i] = arr[i + 1];
    }
    arr[size-1] = -1;
    size--; // Update the size of the array
    return size;
}

int main() {
    const int maxSize = 100;
    int arr[maxSize] = {1, 2, 3, 4, 5};
    int size = 5;

    // Display the original array
    std::cout << "Original Array: ";
    for (int i = 0; i < size; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    int targetToDelete;
    std::cout << "Enter the integer to delete: ";
    std::cin >> targetToDelete;

    // Delete the integer from the array
    size = deleteIntegerFromArray(arr, size, targetToDelete);
    size++;
    // Display the updated array
    std::cout << "Updated Array: ";
    for (int i = 0; i < size; ++i) {
        std::cout << arr[i] << " ";
    }
    std::cout << std::endl;

    return 0;
}