#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <fstream>
using namespace std;

void main ()
{
    int flag = 0,  n , k = 0 ;
    char questions[10][100] , answer[30][30] , mytext[100], tempar[10][30];
    cout << "please enter the number of questions that you would like to answer";
    cin >> n;
    fstream quest("questions.txt");
    while (getline (quest, myText)) {
        // Output the text from the file
        questions[k] == myText;
        k++;
    }
    fstream answer("answer.txt");
    while (getline (answer, myText)) {
        // Output the text from the file
        questions[k] == myText;
        k++;
    }
    while (flag == 0) 
    {
        for(int i = 0; i < n; i++)
        {
            int temp = rand()%6 , pick = rand()%4;
            cout << questions[temp] << endl;
            tempar[pick] = answer[temp];
            for(int j = 0; j < 4; j++)
            {
                if(j == pick)
                    continue;
                else
                    tempar[j] = answer[rand%15];
            }
            for(int j = 0; j < 4; j++)
                cout << setw(3) << j+1 << "." <<tempar[j] << endl;
        }
    }
}