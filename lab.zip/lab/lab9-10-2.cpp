#include <iostream>
#include <stdlib.h>
using namespace std;

int main ()
{
    int n, access = 0, fifo, closest, escelator, k;
    cout << "please enter the amount of process: ";
    cin >> n;
    int process[n], temp[n];
    cout << "please enter the access point in order:\n";
    for(int i = 0; i < n; i++)
    {
        cin >> process[i];
    }
    for(int i = 0; i < n-1; i++)
    {
        if (process[i] > process[i + 1])
            access = access + (process[i] - process[i+1]);
        else
            access = access + (process[i+1] - process[i]);
    }
    cout << "first in first processed algorithm access cilynder number is:" << access;    
}