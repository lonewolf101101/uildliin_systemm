import javax.swing.*;
import java.time.LocalDateTime;   
import java.time.format.DateTimeFormatter;  

class DefaultJFrame {
        public static void main(String[] args) {
            JFrame defaultJFrame = new JFrame();
            defaultJFrame.setSize(300,300);
            defaultJFrame.setVisible(false);

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
            LocalDateTime now = LocalDateTime.now();  
            System.out.println(dtf.format(now)); 


            JOptionPane.showMessageDialog(defaultJFrame, dtf.format(now));
        }
}