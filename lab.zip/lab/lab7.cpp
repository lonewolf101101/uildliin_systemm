#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <cctype>
#include <cstring>
using namespace std;

int main()
{
    int n, j, k = 0;
    char cycle[3] = "  ",input[30];
    cout << "please enter your number of input :";
    cin >> n;
    cout << "Enter the values for the page :\n";
    for (int i = 0; k < n; k++) {
        cin >> input[k];
    }
    j = 0;
    cout << " ";
    for(int k = 0; k < 3; k++)
        cout << setw(8) << "page" << k+1;
    cout << endl;
    for (int i = 0; i < n; i++)
    {
        if (j > 2) j = 0;
        if (cycle[0] == input[i] || cycle[1] == input[i] || cycle[2] == input[i])
        continue;
        cycle[j] = input[i];
        cout << i+1 ;
        for(int k = 0; k < 3; k++)
        {   
            if(isblank(cycle[k]))
            cout << setw(9);
            else
            cout << setw(9) << cycle[k];
        }
        cout << endl ;
        j++;
    }
}