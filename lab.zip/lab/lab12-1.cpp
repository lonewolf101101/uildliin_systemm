#include <iostream>
#include <stdlib.h>
#include <conio.h>
#include <iomanip>
using namespace std;

// Declaration of chamber array
char chamber[20];

int removeDuplicates(char arr[], int n);

int begin(char arr[], int n ,int a);

int length(char arr[], int n ,int a);

int main()
{
    int n, blocks, flag = 0, response, count, size, choice, counter;
    cout << "Enter the number of blocks in the memory: ";
    cin >> n;
    char block[n], A;

    for (int i = 0; i < n; i++)
        block[i] = 'H';

    while (flag == 0)
    {
        cout << "1.Add file\n2.Remove file\n3.Display blocks\n4.End\n";
        cin >> response;

        switch (response)
        {
        case 1:
            cout << "please enter your file name with only one letter:\n";
            cin >> A;
            cout << "Enter the number of blocks in the file:\n";
            cin >> blocks;
            count = 0;

            for (int i = 0; i < n; i++)
                if (block[i] == 'H')
                    count++;
            counter = 0;
            if (blocks <= n && blocks > 0)
            {
                if (count >= blocks)
                {
                    for (int i = 0; i < n; i++){
                        if (block[i] == 'H'){
                            block[i] = A;
                            counter++;
                        }
                        if (counter >=blocks)
                            break;
                    }
                }
                else
                    cout << "there isn't enough space in memory\n";
            }
            else
                cout << "file size is too large or small\n";
            size = removeDuplicates(block, n);
            break;

        case 2:
            size = removeDuplicates(block, n);
            system("cls");
            cout << "the memory\n";
            for (int i = 0; i < size; i++)
            {
                cout << i + 1 << "." <<  setw(4) << chamber[i] << "\n";
            }

            cout << "please choose:";
            cin >> choice;

            for (int i = 0; i < n; i++)
                if (chamber[choice - 1] == block[i])
                    block[i] = 'H';
            break;

        case 3:
            for (int i = 0; i < n; i++)
            {
                cout << i << ".\t" << block[i] << endl;
            }
            if(size != 0)
            {
                cout << "  \tfile\tstart\tlentgh\n";
                for (int i = 0; i < size; i++)
                {
                    cout << i << ".\t"<< chamber[i] << "\t"<< begin(block,n,i) << "\t"<< length(block, n, i) << endl ;
                }
            }
            break;

        case 4:
            flag = 1;
            break;

        default:
            cout << "wrong choice";
            break;
        }
    }
}
int begin(char arr[], int n,int a)
{
    int start;
    for(int i = 0; i < n; i++)
    {
        if(arr[i] == chamber[a])
            {
                start = i;
                break;
            }
    }
    return start;
}

int length(char arr[], int n,int a)
{
    int count = 0;
    for(int i = 0; i < n; i++)
    {
        if(arr[i] == chamber[a])
            count++;
    }
    return count;
}

int removeDuplicates(char arr[], int n)
{
    if (n == 0 || n == 1)
        return n;

    char temp[n];
    int j = 0, k;

    for (int i = 0; i < n - 1; i++)
        if (arr[i] != arr[i + 1] && arr[i] != 'H')
            temp[j++] = arr[i];

    temp[j++] = arr[n - 1];
    for (int i = 0; i < j; i++)
        if(temp[i] == 'H')
            k = i;

    if (k < n)
    {
        // reduce size of array and move all
        // elements on space ahead
        j = j - 1;
        for (int j = k; j < n; j++)
            temp[j] = temp[j+1];
    }

    for (int i = 0; i < j; i++)
        chamber[i] = temp[i];

    return j;
}