#include <iostream>
#include <stdlib.h>
#include <iomanip>
using namespace std;

struct process{
	int time , priority , waiting_time=0 , turn_around_time;
};



void first_comes(struct process process[] , int n)
{
	int temp = 0 ;
	for(int i = 0; i < n; i++)
	{
		process[i].waiting_time = temp;
		temp += process[i].time;
		process[i].turn_around_time = temp;  
	} 
}

void shortest_job(struct process process[] , int n)
{
	int temp = 0 ;
	
	
    for (int i = 1; i < n; ++i) 
	{
        int key = process[i].time;
        int j = i - 1;
            while (j >= 0 && process[j].time > key) 
			{
                process[j + 1].time = process[j].time;
                j = j - 1;
            }
        process[j + 1].time = key;
    }
    
	for(int i = 0; i < n; i++)
	{
		process[i].waiting_time = temp;
		temp += process[i].time;
		process[i].turn_around_time = temp;  
	}
}

void priority_scheduling(struct process process[] , int n)
{
	cout << "please enter the priorities of each process";
	
	for(int i = 0 ; i < n ; i++)
	{
		cout << "the priority of process" << i+1 << ":";
		cin >> process[i].priority;
	}
	
	int flag=0 , temp , key;
	
	for (int i = 1; i < n; ++i) 
	{
        temp = process[i].time , key = process[i].priority;
        int j = i - 1;
            while (j >= 0 && process[j].priority > key) 
			{
                process[j + 1].priority = process[j].priority;
                process[j + 1].time = process[j].time;
                j = j - 1;
            }
        
        process[j + 1].priority = temp;
        process[j + 1].priority = key;
    }
    temp = 0;
    for(int i = 0; i < n; i++)
	{
		process[i].waiting_time = temp;
		temp += process[i].time;
		process[i].turn_around_time = temp;  
	}
}

void round_robin(struct process process[] , int n)
{
	int turn = 0 , temp = process[0].time , j , time[n];
	for(int i = 0; i < n; i++)
	{
		if(temp < process[i].time )
		{
			temp = process[i].time;
			j = i;
		}
		time[i] = process[i].time;
	}
	
	
	while(time[j] != 0)
	{
		for(int i = 0; i < n ; i++)
		{
			if (time[i] == 0)
				continue;
			process[i].waiting_time = temp;
			time[i] --;
			temp ++;
			process[i].turn_around_time = temp; 
		}
	}
}

void print(struct process process[] , int n)
{
	system("cls");
	cout << " #\tservice\t  turn\t wait\t\n";
	for(int i = 0; i < n ; i++)
	{
		cout << setw(1) << i+1;
		cout << setw(14) << process[i].time;
		cout << setw(7) << process[i].turn_around_time;
		cout << setw(7) << process[i].waiting_time;
		cout << "\n";
	}
}





int main()
{
	int n , flag = 0 , response ;
	cout << "please enter the amount of processes:";
	cin >> n;
	
	struct process process[n];
	
	for(int i=0 ; i < n ; i++)
	{
		cout << "the service time process " << i+1 << ":";
		cin >> process[i].time;
	}
	
	while(flag == 0)
	{
		cout << "1. first comes first\n2. shortest job first\n3. round robin scheduling\n4. priority scheduling\n5. QUIT\n";
		cin >> response ;
		switch (response)
		{
			case 1:
				first_comes(process , n);
				print(process , n);
				break;
				
			case 2:
				shortest_job(process , n);
				print(process , n);
				break;
				
			case 3:
				round_robin(process , n);
				print(process , n);
				break;
				
			case 4:
				priority_scheduling(process , n);
				print(process , n);
				break;
				
			case 5:
				flag = 1;
				break;
				
			default:
				cout << "wrong response" ;
				break;
		}
	}
}
