#include <iostream>
#include <stdlib.h>
using namespace std;

int main ()
{
    double temp, capacity, speed, time, storage, transfer, answer;
    cout << "please enter the capacity for disk path:";
    cin >> capacity;
    cout << "please the rotatino speed for disk:";
    cin >> speed;
    cout << "please enter the avarage seek time for disk:";
    cin >> time; 
    cout << "please enter the total storage size of disk:";
    cin >> storage;

    speed /= 60;
    temp = speed;
    speed = 1 / speed;
    speed = 1000 * speed / 2;
    transfer = temp * capacity;
    answer = (storage / transfer) * 1000;
    answer = answer + speed + time;
    cout << "the access time is :" << answer;
}