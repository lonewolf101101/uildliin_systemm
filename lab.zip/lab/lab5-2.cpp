#include <iostream>
#include <stdlib.h>
#include <iomanip>
using namespace std;

int main()
{
    double cache_hit , memory , cache , effective;
    cout << "please enter the memory access time: ";
    cin >> memory ;
    cout << "please enter the cache acces time: ";
    cin >> cache ;
    cout << "please enter cache hit rate: ";
    cin >> cache_hit  ;
    cache_hit = cache_hit / 100;
    effective = (cache_hit * cache) + (( 1 - cache_hit) * memory);
    cout << fixed << setprecision(2) << "The Effective Access Time Is : "<< effective << endl;
}