#include <iostream>
#include <stdlib.h>
#include <iomanip>
using namespace std;

int main()
{
	int n ;
	
	cout << "please enter the amount of processes:";
	cin >> n;
	
	double speed[n] , freq[n] , answer = 0;
	
	for(int i = 0;i < n; i++)
	{
		cout << "the speed of the process " << i+1 << ":";
		cin >> speed[i];
		cout << "the freuincy of the process " << i+1 << ":";
		cin >> freq[i];
		cout << "\n";
	}
	
	for(int i = 0;i < n; i++)
	{
		freq[i] /= 100;
		answer = answer + freq[i] * speed[i];
	}
	
	answer = 1 / answer;
	
	cout << "MIPS :" << answer;
}
