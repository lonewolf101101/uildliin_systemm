import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.Desktop;  
import java.io.*;  

class JListSample extends JFrame
                           implements ActionListener {

//----------------------------------
//    Data Members
//----------------------------------
    private static final int FRAME_WIDTH    = 300;
    private static final int FRAME_HEIGHT   = 250;
    private static final int FRAME_X_ORIGIN = 150;
    private static final int FRAME_Y_ORIGIN = 250;

    private JList list;

//----------------------------------
//      Main method
//----------------------------------
    public static void main(String[] args) {
        JListSample frame = new JListSample();
        frame.setVisible(true);
    }

//----------------------------------
//    Constructors
//----------------------------------
    public JListSample() {
        Container   contentPane;
        JPanel      listPanel, okPanel;

        JButton     okButton;
        String[]    names = {"date", "picture","ipconfig"};

        //set the frame properties
        setSize      (FRAME_WIDTH, FRAME_HEIGHT);
        setTitle     ("Program JListSample2");
        setLocation  (FRAME_X_ORIGIN, FRAME_Y_ORIGIN);

        contentPane = getContentPane( );
        contentPane.setBackground(Color.WHITE);
        contentPane.setLayout(new BorderLayout());

        //create and place a JList
        listPanel = new JPanel(new GridLayout(0,1));
        listPanel.setBorder(BorderFactory.createTitledBorder(
                                          "Three-letter Animal Names"));

        list = new JList(names);
        listPanel.add(new JScrollPane(list));
        list.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
            //this is default, so the explicit call is not necessary

        //---------------------------------------
        //Other selection modes
        //
        //list.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        //list.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        //---------------------------------------

        //create and place the OK button
        okPanel = new JPanel(new FlowLayout());
        okButton = new JButton("OK");
        okButton.addActionListener(this);
        okPanel.add(okButton);

        contentPane.add(listPanel, BorderLayout.CENTER);
        contentPane.add(okPanel, BorderLayout.SOUTH);

        //register 'Exit upon closing' as a default close operation
        setDefaultCloseOperation( EXIT_ON_CLOSE );
    }

    public void actionPerformed(ActionEvent event) {

        Object[] name;
        int[]    loc;
        String[] s= {"C:\\Users\\lonewolf\\OneDrive\\Desktop\\dateof.jar", "C:\\Users\\lonewolf\\OneDrive\\Desktop\\FGZC-9EXsAE5X-I.jpg" ,"C:\\Users\\lonewolf\\Downloads\\ipconfig.py" };
        name = list.getSelectedValues();
        loc  = list.getSelectedIndices();

        for (int i = 0; i < name.length; i++) {
            program(s[loc[i]]);
        }   
    }
    
    public void program(String s)
    {
        try  
        {  
        //constructor of file class having file as argument  
        File file = new File(s);   
        if(!Desktop.isDesktopSupported())//check if Desktop is supported by Platform or not  
        {  
        System.out.println("not supported");  
        return;  
        }  
        Desktop desktop = Desktop.getDesktop();  
        if(file.exists())         //checks file exists or not  
        desktop.open(file);              //opens the specified file  
        }  
        catch(Exception e)  
        {  
        e.printStackTrace();  
        } 
    }
}