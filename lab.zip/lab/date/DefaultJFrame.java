import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime;   
import java.time.format.DateTimeFormatter;  

class DefaultJFrame {
        public static void main(String[] args) {
            JFrame defaultJFrame = new JFrame("date and time");
            defaultJFrame.setSize(400,200);
            defaultJFrame.setLocation(100,200);
            defaultJFrame.setVisible(true);   
            Container contentPane=new Container();         
            
            
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm");  
            LocalDateTime now = LocalDateTime.now();

            JLabel text = new JLabel(dtf.format(now));
            Font fo = new Font("Serif", Font.BOLD, 50);
            text.setFont(fo);
            contentPane.add(text);
            
            defaultJFrame.add(contentPane);            
        }
}