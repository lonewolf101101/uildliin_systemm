#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <fstream>
using namespace std;

int main()
{
    int n, k = 0 ,flag = 0 ,ans ,point = 0;
    string questions[10], answer[30], mytext, tempar[4];
    cout << "Please enter the number of questions that you would like to answer: ";
    cin >> n;

    fstream questionsFile("questions.txt");
    while (getline(questionsFile, mytext)) {
        // Copy the text from the file
        questions[k] = mytext;
        k++;
    }

    k = 0; // Reset k to 0

    fstream answersFile("answer.txt");
    while (getline(answersFile, mytext)) {
        // Copy the text from the file
        answer[k] = mytext;
        k++;
    }

    while (flag == 0) 
    {
        for(int i = 0; i < n; i++)
        {
            int temp = rand() % 6, pick = rand() % 4;
            cout << questions[temp] << endl;
            tempar[pick] = answer[temp];

            for (int j = 0; j < 4; j++)
            {
                if (j == pick)
                    continue;
                else
                    tempar[j] = answer[rand() % 15];
            }

            for (int j = 0; j < 4; j++)
                cout << setw(3) << j + 1 << "." << tempar[j] << endl;
            cout << "please enter your answer";
            cin >> ans;
            if(ans-1 == pick)
            {
                point++;
            }
        }
        if(point > 0)
        {
            cout << "you pass with " << point << " 2points\n";
            flag = 1;
        }
    }
    return 0;
}