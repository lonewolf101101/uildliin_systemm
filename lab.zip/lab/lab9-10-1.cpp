#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <cstring>
using namespace std;

int main ()
{
    int cylo, gate, space, capapcity;
    cout << "Enter the number of cilynder's:";
    cin >> cylo;
    cout << "Enter the number of gateways for each cylinder's:";
    cin >> gate;
    cout << "Enter the number of spaces for each gateway's:";
    cin >> space;
    if (cylo <= 0 || gate <= 0 || space <= 0) 
    {
        cout<<"Invalid input! Please enter positive numbers.";
        return -1;
    } 
    else 
    {
        capapcity = cylo * gate * space;
        cout << "\nThe total capacity is : " << capapcity;
    }
}