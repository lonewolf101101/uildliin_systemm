#include <iostream>
#include <stdlib.h>
#include <iomanip>
using namespace std;

int main ()
{
    int n ;
    cout << "please enter the amount of processes";
    cin >> n;
    int limit[n] , order[n] , base[n] ;
    
    for(int i = 0; i < n ; i++)
    {
        cout << "please enter the limit for " << i <<"th:";
        cin >> limit[i] ;
    }
    
    base[0] = 0;
    for(int i = 1; i < n ; i++)
    {
        base[i] = limit[i - 1] + base[i - 1] + 4 ;
    }
    cout << "process|   base|\tlimit\n";
    for(int i = 0; i < n ; i++)
    {
        cout << setw(7) << i + 1 << "|" << setw(7) << base[i] << "|" << setw(13) << limit[i]<<"\n";
    } 
    
}