import datetime
import itertools
import numpy as np
import matplotlib.pyplot as plt
import math

def convert_duration(sec):
    units = [
        ('sec', 1),
        ('msec', 1e3),  
        ('microsec', 1e6),  
        ('nsec', 1e9),  
        ('psec', 1e12) 
    ]

    for unit, divisor in units:
        converted_duration = sec * divisor
        if 1 <= converted_duration < 1000:
            return converted_duration, unit

    return sec , 'unknown'



plt.figure(figsize=(10, 10))
CPUs = [1, 2]
time=[]
comb = np.array(list(itertools.combinations_with_replacement(CPUs, 3)))
categories = np.array(['CPU1', 'CPU2'])
TASK_ = np.array([10e-3, 15e-3, 30e-3])
i = 1
colors=['blue','cyan','violet']
for combo in comb:
    values_ = np.zeros(2)
    plt.subplot(2, 2, i)
    for j in range(3):
        if combo[j] == 1:
            temp = values_.copy()
            values_[0] += TASK_[j]
            plt.bar(categories, [TASK_[j],0], color=colors[j], bottom=temp)
        elif combo[j] == 2:
            temp = values_.copy()
            values_[1] += TASK_[j]
            plt.bar(categories, [0,TASK_[j]], color=colors[j], bottom=temp)
    i += 1
    plt.title(f'{combo}')

    time.append(convert_duration(max(sum(TASK_[combo == 1]), sum(TASK_[combo == 2]))))
print(min(time))
plt.tight_layout()
plt.show()