
public interface Interface {

}
