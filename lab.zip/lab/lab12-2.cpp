
#include <iostream>
#include <stdlib.h>
#include <conio.h>
#include <iomanip>
using namespace std;

// Function to delete an element from the array
void deleter(int arr[], int size, int target);

// Function to delete an element from the array
int deleters(char arr[], int size, int target);

// Function to delete a file from memory
void truedelete(int arr[], int n, int start);

int arrcounter(int arr[], int n, int start);
int main()
{
    int n, blocks, flag = 0, response, count, size, choice, counter, newwer = 0, temple;
    char chamber[20], A;
    cout << "Enter the number of blocks in the memory: ";
    cin >> n;
    int block[n], start[20], ending[20];

    for (int i = 0; i < n; i++)
        block[i] = -10;

    while (flag == 0)
    {
        cout << "1.Add file\n2.Remove file\n3.Display blocks\n4.End\n";
        cin >> response;

        switch (response)
        {
        case 1:
            cout << "please enter your file name with only one letter:\n";
            cin >> A;
            cout << "Enter the number of blocks in the file:\n";
            cin >> blocks;
            count = 0;

            for (int i = 0; i < n; i++)
                if (block[i] == -10)
                    count++;
            counter = 0;
            if (blocks <= n && blocks > 0)
            {
                if (count >= blocks)
                {
                    chamber[newwer] = A;

                    int tempest, spare;
                    while (counter < blocks)
                    {
                        tempest = rand() % size;
                        if (block[tempest] == -10)
                        {
                            start[newwer] = tempest;
                            spare = tempest;
                            counter++;
                            break;
                        }
                    }
                    while (counter < blocks)
                    {
                        tempest = rand() % size;
                        if (block[tempest] == -10)
                        {
                            block[spare] = tempest;
                            spare = tempest;
                            counter++;
                        }
                    }
                    block[spare] = -1;
                    ending[newwer] = spare;
                    newwer++;
                }
                else
                    cout << "there isn't enough space in memory\n";
            }
            else
                cout << "file size is too large or small\n";
            break;

        case 2:
            system("cls");
            cout << "the memory\n";
            for (int i = 0; i < newwer; i++)
            {
                cout << i+1  << "." << setw(4) << chamber[i] << "\n";
            }
            temple = newwer;
            cout << "please choose:";
            cin >> choice;
            truedelete(block, n, start[choice - 1]);
            newwer = deleters(chamber, newwer, choice - 1);
            deleter(start, temple, choice - 1);
            deleter(ending, temple, choice - 1);
            break;

        case 3:
            for (int i = 0; i < n; i++)
            {
                cout << i << ".\t" << block[i] << endl;
            }
            cout << "  \tfile\tstart\tend\tlength\n";
            for (int i = 0; i < newwer; i++)
            {
                cout << i << ".\t" << chamber[i] << "\t" << start[i] << "\t" << ending[i] << "\t" << arrcounter(block, n, start[i]) << endl;
            }
            break;

        case 4:
            flag = 1;
            break;

        default:
            cout << "wrong choice";
            break;
        }
    }
}

// Function to delete an element from the array
void deleter(int arr[], int size, int target)
{
    // Shift elements to remove the target element
    for (int i = target; i < size - 1; ++i)
    {
        arr[i] = arr[i + 1];
    }
    arr[size - 1] = -10;
}

// Function to delete an element from the array
int deleters(char arr[], int size, int target)
{
    // Shift elements to remove the target element
    for (int i = target; i < size - 1; ++i)
    {
        arr[i] = arr[i + 1];
    }
    arr[size - 1] = 'E';
    size--; // Update the size of the array
    return size;
}

// Function to delete a file from memory
void truedelete(int arr[], int n, int start)
{
    int flag = start, temp;
    temp = arr[start];
    arr[start] = -10;
    while (flag != -1)
    {
        flag = temp;
        temp = arr[temp];
        arr[flag] = -10;
    }
}

int arrcounter(int arr[], int n, int start)
{
    int flag = start, temp, count;
    temp = arr[start];
    count = 0;
    while (flag != -1)
    {
        flag = temp;
        temp = arr[temp];
        count++;
    }
    return count;
}
//This code simulates a memory management system for a computer. It allows the user to add files to memory, remove files from memory, and display the current state of memory. The code uses arrays to represent memory blocks and files. The functions `deleter`, `deleters`, and `truedelete` are used to remove elements from the arrays.