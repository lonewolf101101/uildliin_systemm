#include <iostream>
#include <stdlib.h>
using namespace std;

int main()
{
	double freq , answer ;
	int unit ;
	cout << "the frequency is :";
	cin >> freq ;
	cout << "what is the unit" ;
	cout << "\n1.kilo \n2.mega \n3.gega\n";
	cin >> unit;
	answer=1/freq;
	if(answer<1)
	{
		answer*=1000;
		unit++;
	}
	switch (unit)
	{
		case 1:
			cout<<"1 pulse for every "<<answer<<"milsecond";
			break;
		case 2:
			cout<<"1 pulse for every "<<answer<<"microsecond";
			break;
		case 3:
			cout<<"1 pulse for every "<<answer<<"nanosecond";
			break;
		case 4:
			cout<<"1 pulse for every "<<answer<<"picosecond";
			break;
	}
}
