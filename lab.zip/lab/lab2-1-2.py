import datetime
import itertools
import numpy as np
import matplotlib.pyplot as plt
import math

def convert_duration(sec):
    units = [
        ('sec', 1),
        ('msec', 1e3),  
        ('microsec', 1e6),  
        ('nsec', 1e9),  
        ('psec', 1e12) 
    ]

    for unit, divisor in units:
        converted_duration = sec * divisor
        if 1 <= converted_duration < 1000:
            return converted_duration, unit

    return sec , 'unknown'


plt.figure(figsize=(10, 10))
CPUs = [1, 2, 3]
comb = np.array(list(itertools.combinations_with_replacement(CPUs, 4)))
categories = np.array(['CPU1', 'CPU2', 'CPU3'])
TASK_ = np.array([6e-3, 12e-3, 15e-3, 25e-3])
i = 1
colors=['blue','cyan','violet', 'black']
time=[]
for combo in comb:
    values_ = np.zeros(3)
    plt.subplot(4, 4, i)
    for j in range(4):
        if combo[j] == 1:
            temp = values_.copy()
            values_[0] += TASK_[j]
            plt.bar(categories, [TASK_[j],0,0], color=colors[j], bottom=temp)
        elif combo[j] == 2:
            temp = values_.copy()
            values_[1] += TASK_[j]
            plt.bar(categories, [0,TASK_[j],0], color=colors[j], bottom=temp)
        elif combo[j] == 3:
            temp = values_.copy()
            values_[2] += TASK_[j]
            plt.bar(categories, [0,0,TASK_[j]], color=colors[j], bottom=temp)
    i += 1
    plt.title(f'{combo}')

    time.append(convert_duration(max(sum(TASK_[combo == 1]), sum(TASK_[combo == 2]),  sum(TASK_[combo == 3]))))
print(min(time))
plt.tight_layout()
plt.show()