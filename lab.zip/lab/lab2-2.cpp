
#include<iostream>
#include <stdlib.h>
using namespace std;

int main (){
	unsigned long int n , answer=0 , tact , order , j;
	cout << "how many different processes are there :";
	cin >> n;
	int p[n];
	cout << "how long is 1 cpi :";
	cin >> tact;
	for (int i=0;i<n;i++)
	{
		cout << "how many cpi is p"<<i+1<<" :";
		cin >> p[i];
		p[i] *= tact;
	}
	cout << "haw many processes is there :";
	cin >> order;
	cout << "please enter the order :\n";
	for (int i=0;i<order;i++)
	{
		cin >> j;
		j--;
		answer += p[j];
	}
	cout << "the time needed to finish all the process is " << answer << "milsec";
}
